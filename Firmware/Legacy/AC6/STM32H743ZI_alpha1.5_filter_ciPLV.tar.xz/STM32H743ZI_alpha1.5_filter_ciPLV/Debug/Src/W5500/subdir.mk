################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/W5500/dhcp.c \
../Src/W5500/dns.c \
../Src/W5500/socket.c \
../Src/W5500/w5500.c \
../Src/W5500/wizchip_conf.c 

OBJS += \
./Src/W5500/dhcp.o \
./Src/W5500/dns.o \
./Src/W5500/socket.o \
./Src/W5500/w5500.o \
./Src/W5500/wizchip_conf.o 

C_DEPS += \
./Src/W5500/dhcp.d \
./Src/W5500/dns.d \
./Src/W5500/socket.d \
./Src/W5500/w5500.d \
./Src/W5500/wizchip_conf.d 


# Each subdirectory must supply rules for building sources it contributes
Src/W5500/%.o: ../Src/W5500/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU GCC Compiler'
	@echo $(PWD)
	arm-none-eabi-gcc -mcpu=cortex-m7 -mthumb -mfloat-abi=hard -mfpu=fpv5-d16 '-D__weak=__attribute__((weak))' '-D__packed="__attribute__((__packed__))"' -DUSE_HAL_DRIVER -DSTM32H743xx -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Inc" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/STM32H7xx_HAL_Driver/Inc" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/STM32H7xx_HAL_Driver/Inc/Legacy" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Device/ST/STM32H7xx/Include" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Include"  -Og -g3 -Wall -fmessage-length=0 -ffunction-sections -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


