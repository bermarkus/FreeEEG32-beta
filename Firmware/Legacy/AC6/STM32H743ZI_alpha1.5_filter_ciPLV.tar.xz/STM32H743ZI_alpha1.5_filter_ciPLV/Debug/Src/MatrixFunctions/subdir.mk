################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/MatrixFunctions/arm_mat_init_f32.c \
../Src/MatrixFunctions/arm_mat_mult_f32.c \
../Src/MatrixFunctions/arm_mat_trans_f32.c 

OBJS += \
./Src/MatrixFunctions/arm_mat_init_f32.o \
./Src/MatrixFunctions/arm_mat_mult_f32.o \
./Src/MatrixFunctions/arm_mat_trans_f32.o 

C_DEPS += \
./Src/MatrixFunctions/arm_mat_init_f32.d \
./Src/MatrixFunctions/arm_mat_mult_f32.d \
./Src/MatrixFunctions/arm_mat_trans_f32.d 


# Each subdirectory must supply rules for building sources it contributes
Src/MatrixFunctions/%.o: ../Src/MatrixFunctions/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU GCC Compiler'
	@echo $(PWD)
	arm-none-eabi-gcc -mcpu=cortex-m7 -mthumb -mfloat-abi=hard -mfpu=fpv5-d16 '-D__weak=__attribute__((weak))' '-D__packed="__attribute__((__packed__))"' -DUSE_HAL_DRIVER -DSTM32H743xx -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Inc" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/STM32H7xx_HAL_Driver/Inc" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/STM32H7xx_HAL_Driver/Inc/Legacy" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Device/ST/STM32H7xx/Include" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Include"  -Og -g3 -Wall -fmessage-length=0 -ffunction-sections -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


