Src/MatrixFunctions/arm_mat_mult_f32.o: \
 ../Src/MatrixFunctions/arm_mat_mult_f32.c \
 /home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Inc/arm_math.h \
 /home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Include/cmsis_compiler.h \
 /home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Include/cmsis_gcc.h

/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Inc/arm_math.h:

/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Include/cmsis_compiler.h:

/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32H743ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Include/cmsis_gcc.h:
