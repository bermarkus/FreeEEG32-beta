################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/ad7779.c \
../Src/main.c \
../Src/platform_drivers.c \
../Src/stm32f7xx_hal_msp.c \
../Src/stm32f7xx_it.c \
../Src/syscalls.c \
../Src/system_stm32f7xx.c 

OBJS += \
./Src/ad7779.o \
./Src/main.o \
./Src/platform_drivers.o \
./Src/stm32f7xx_hal_msp.o \
./Src/stm32f7xx_it.o \
./Src/syscalls.o \
./Src/system_stm32f7xx.o 

C_DEPS += \
./Src/ad7779.d \
./Src/main.d \
./Src/platform_drivers.d \
./Src/stm32f7xx_hal_msp.d \
./Src/stm32f7xx_it.d \
./Src/syscalls.d \
./Src/system_stm32f7xx.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o: ../Src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU GCC Compiler'
	@echo $(PWD)
	arm-none-eabi-gcc -mcpu=cortex-m7 -mthumb -mfloat-abi=hard -mfpu=fpv5-d16 '-D__weak=__attribute__((weak))' '-D__packed="__attribute__((__packed__))"' -DUSE_HAL_DRIVER -DSTM32F765xx -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32F765ZI_alpha1.5_filter_ciPLV/Inc" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32F765ZI_alpha1.5_filter_ciPLV/Drivers/STM32F7xx_HAL_Driver/Inc" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32F765ZI_alpha1.5_filter_ciPLV/Drivers/STM32F7xx_HAL_Driver/Inc/Legacy" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32F765ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Device/ST/STM32F7xx/Include" -I"/home/dmitryneuro/usr/eclipse-stm32-workspace/STM32F765ZI_alpha1.5_filter_ciPLV/Drivers/CMSIS/Include"  -Og -g3 -Wall -fmessage-length=0 -ffunction-sections -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


