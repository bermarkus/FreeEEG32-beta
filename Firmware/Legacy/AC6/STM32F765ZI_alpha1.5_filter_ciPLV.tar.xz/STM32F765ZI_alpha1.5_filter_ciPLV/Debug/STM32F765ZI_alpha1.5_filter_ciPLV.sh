/usr/local/bin/stm32flash /dev/ttyUSB0 -v -w ./STM32F765ZI_alpha1.5_filter_ciPLV.hex
