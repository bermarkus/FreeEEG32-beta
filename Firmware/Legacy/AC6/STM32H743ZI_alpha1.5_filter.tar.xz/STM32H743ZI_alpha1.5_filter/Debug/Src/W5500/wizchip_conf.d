Src/W5500/wizchip_conf.o: ../Src/W5500/wizchip_conf.c \
 ../Src/W5500/wizchip_conf.h ../Src/W5500/../W5500/w5500.h \
 ../Src/W5500/../W5500/../W5500/wizchip_conf.h

../Src/W5500/wizchip_conf.h:

../Src/W5500/../W5500/w5500.h:

../Src/W5500/../W5500/../W5500/wizchip_conf.h:
