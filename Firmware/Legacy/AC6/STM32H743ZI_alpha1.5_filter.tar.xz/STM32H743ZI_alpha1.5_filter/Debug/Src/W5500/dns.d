Src/W5500/dns.o: ../Src/W5500/dns.c ../Src/W5500/socket.h \
 ../Src/W5500/../W5500/wizchip_conf.h \
 ../Src/W5500/../W5500/../W5500/w5500.h \
 ../Src/W5500/../W5500/../W5500/../W5500/wizchip_conf.h \
 ../Src/W5500/dns.h

../Src/W5500/socket.h:

../Src/W5500/../W5500/wizchip_conf.h:

../Src/W5500/../W5500/../W5500/w5500.h:

../Src/W5500/../W5500/../W5500/../W5500/wizchip_conf.h:

../Src/W5500/dns.h:
